JSON Schema is a repository for the JSON Schema specification, reference schemas and a CommonJS implementation of JSON Schema (not the only JavaScript implementation of JSON Schema, JSV is another excellent JavaScript validator).

Code is licensed under the AFL or BSD license as part of the Persevere 
project which is administered under the Dojo foundation,
and all contributions require a Dojo CLA.