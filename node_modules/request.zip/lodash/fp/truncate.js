var convert = require('./convert'),
    func = convert('truncate', require('../truncate'));

func.placeholder = require('./placeholder');
module.exports = func;
